/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOdatarental;

import DAOimplement.datakendaraanimplement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import koneksi.connector;
import model.datakendaraan;

/**
 *
 * @author ACER
 */
public class datakendaraanDAO implements datakendaraanimplement {
    Connection connection;
    
    final String select = "SELECT * FROM kendaraan";
    final String insert = "INSERT INTO `kendaraan`(`nama_kendaraan`, `tipe_kendaraan`, `plat`, `harga`, `status`) VALUES (?,?,?,?,?)";
    final String update = "UPDATE kendaraan SET nama_kendaraan=?, tipe_kendaraan=?, plat=?, harga=?, status=? WHERE id_kendaraan=?";
    final String delete = "DELETE FROM kendaraan WHERE id_kendaraan=?";

            
    public datakendaraanDAO(){
        connection = connector.connection();
    }
    
    @Override
    public void insert(datakendaraan p) {
         PreparedStatement statement = null;
    try{

        statement = connection.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
        statement.setString(1, p.getNama_kendaraan());
        statement.setString(2, p.getTipe_kendaraan());
        statement.setString(3, p.getPlat_kendaraan());
        statement.setInt(4, p.getHarga());
        statement.setString(5, p.getStatus()); // Menyetel nilai yang telah dihitung
        statement.executeUpdate();
        
        ResultSet rs = statement.getGeneratedKeys();
       
    }catch(SQLException ex){
        ex.printStackTrace();
    }finally{
        try{
            statement.close();
        }catch(SQLException ex){
            ex.printStackTrace();
        }
    }
    }

    @Override
    public void update(datakendaraan p) {
        PreparedStatement statement = null;
    try {
        statement = connection.prepareStatement(update);
        
        statement.setString(1, p.getNama_kendaraan());
        statement.setString(2, p.getTipe_kendaraan());
        statement.setString(3, p.getPlat_kendaraan());
        statement.setInt(4, p.getHarga());
        statement.setString(5, p.getStatus()); 
        statement.setInt(6, p.getId_kendaraan());

        
        statement.executeUpdate();
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            if (statement != null) {
                statement.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    }

    @Override
    public void delete(int id) {
        PreparedStatement statement = null;
    try {
        statement = connection.prepareStatement(delete);
        
        statement.setInt(1, id);
        
        statement.executeUpdate();
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            if (statement != null) {
                statement.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    }

    @Override
    public List<datakendaraan> getAll() {
        List<datakendaraan> dp = new ArrayList<>();
        try {
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while (rs.next()) {
                datakendaraan dk = new datakendaraan();
                dk.setId_kendaraan(rs.getInt("id_kendaraan"));
                dk.setNama_kendaraan(rs.getString("nama_kendaraan"));
                dk.setTipe_kendaraan(rs.getString("tipe_kendaraan"));
                dk.setPlat_kendaraan(rs.getString("plat"));
                dk.setHarga(rs.getInt("harga"));
                dk.setStatus(rs.getString("status"));
                
                
                dp.add(dk);
            }
        } catch (SQLException ex) {
            Logger.getLogger(datakendaraanDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        return dp;
    }
    
}
