/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOdatarental;

import DAOimplement.datapeminjamanimplement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import koneksi.connector;
import model.datakendaraan;
import model.datapeminjaman;

/**
 *
 * @author ACER
 */
public class datapeminjamanDAO implements datapeminjamanimplement {

    Connection connection;

    final String select = "SELECT * FROM kendaraan WHERE status = 'Tersedia'";
    final String insert = "INSERT INTO `peminjaman`( `nama_customer`, `nik`, `no_telp`, `lama_sewa`, `total`,`id_kendaraan`) VALUES (?,?,?,?,?,?)";
    final String updateStatus = "UPDATE kendaraan SET status = ? WHERE id_kendaraan = ?";
    final String search = "select * from kendaraan where nama_kendaraan like ? and status = 'Tersedia' ";


    public datapeminjamanDAO() {
        connection = connector.connection();
    }

    @Override
    public void insert(datapeminjaman p) {
        PreparedStatement statement = null;
    ResultSet generatedKeys = null;
    try {
        statement = connection.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
        statement.setString(1, p.getNama_customer());
        statement.setString(2, p.getNik());
        statement.setString(3, p.getNo_telp());
        statement.setInt(4, p.getLama_sewa());
        statement.setInt(5, p.getTotal());
        statement.setInt(6, p.getId_kendaraan());

        statement.executeUpdate();

        generatedKeys = statement.getGeneratedKeys();
        if (generatedKeys.next()) {
            int id = generatedKeys.getInt(1); 
            p.setKode_peminjaman(id); 
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            if (generatedKeys != null) {
                generatedKeys.close();
            }
            if (statement != null) {
                statement.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    }

    

   

    @Override
    public List<datakendaraan> getAll() {
        List<datakendaraan> dp = new ArrayList<>();
        try {
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while (rs.next()) {
                datakendaraan dk = new datakendaraan();
                dk.setId_kendaraan(rs.getInt("id_kendaraan"));
                dk.setNama_kendaraan(rs.getString("nama_kendaraan"));
                dk.setTipe_kendaraan(rs.getString("tipe_kendaraan"));
                dk.setPlat_kendaraan(rs.getString("plat"));
                dk.setHarga(rs.getInt("harga"));
                dk.setStatus(rs.getString("status"));

                dp.add(dk);
            }
        } catch (SQLException ex) {
            Logger.getLogger(datakendaraanDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return dp;
    }

    @Override
    public void updateStatusKendaraan(int idKendaraan, String status) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(updateStatus);
            statement.setString(1, status);
            statement.setInt(2, idKendaraan);
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (statement != null) {
                    statement.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<datakendaraan> search(String namaKendaraan) {
        List<datakendaraan> dp = new ArrayList<>();
        try {
            PreparedStatement ps = connection.prepareStatement(search);
            ps.setString(1, "%" + namaKendaraan + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                datakendaraan dk = new datakendaraan();
                dk.setId_kendaraan(rs.getInt("id_kendaraan"));
                dk.setNama_kendaraan(rs.getString("nama_kendaraan"));
                dk.setTipe_kendaraan(rs.getString("tipe_kendaraan"));
                dk.setPlat_kendaraan(rs.getString("plat"));
                dk.setHarga(rs.getInt("harga"));
                dk.setStatus(rs.getString("status"));

                dp.add(dk);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dp;
    
    }
    }


