/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import DAOdatarental.datapeminjamanDAO;
import DAOimplement.datapeminjamanimplement;
import java.util.List;
import model.datakendaraan;
import model.datapeminjaman;
import model.modeltabeldatakendaraan;
import view.framePeminjaman;

public class datapeminjamancontroller {
    framePeminjaman frame;
    datapeminjamanimplement impldatapinjam;
    List<datakendaraan> dk;
    
    
    public datapeminjamancontroller(framePeminjaman frame){
        this.frame = frame;
        impldatapinjam = new datapeminjamanDAO();
        dk = impldatapinjam.getAll();
    }
    
    public void isitabel(){
        dk = impldatapinjam.getAll();
        modeltabeldatakendaraan mp = new modeltabeldatakendaraan(dk);
        frame.getTabelKendaraan2().setModel(mp);
    }
    
    public void insert(){
        datapeminjaman dp = new datapeminjaman();
        dp.setNama_customer(frame.getJTxtNama().getText());
        dp.setNik(frame.getJTxtNIK().getText());
        dp.setNo_telp(frame.getJTxtNoTelp().getText());
        Integer sewa = Integer.parseInt(frame.getJTxtWaktuSewa().getText());
        dp.setLama_sewa(sewa);
         Integer Total = Integer.parseInt(frame.getJtxtTotal().getText());
        dp.setTotal(Total);
        dp.setId_kendaraan(frame.getSelectedKendaraanId());
        impldatapinjam.insert(dp);
    }
    public void updateStatusKendaraan(int idKendaraan, String status) {
    impldatapinjam.updateStatusKendaraan(idKendaraan, status);
}
    public void search(String namaKendaraan) {
        dk = impldatapinjam.search(namaKendaraan);
        modeltabeldatakendaraan mp = new modeltabeldatakendaraan(dk);
        frame.getTabelKendaraan2().setModel(mp);
    }
}


