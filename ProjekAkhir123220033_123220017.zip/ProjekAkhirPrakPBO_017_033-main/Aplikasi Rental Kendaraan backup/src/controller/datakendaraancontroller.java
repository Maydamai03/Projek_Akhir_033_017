/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import DAOdatarental.datakendaraanDAO;
import DAOimplement.datakendaraanimplement;
import java.util.List;
import model.datakendaraan;
import model.modeltabeldatakendaraan;
import view.frameAddKendaraan;

public class datakendaraancontroller {
    frameAddKendaraan frame;
    datakendaraanimplement impldatakendaraan;
    List<datakendaraan> dk;
    
    public datakendaraancontroller(frameAddKendaraan frame){
        this.frame = frame;
        impldatakendaraan = new datakendaraanDAO();
        dk = impldatakendaraan.getAll();
    }
    
    public void isitabel(){
        dk = impldatakendaraan.getAll();
        modeltabeldatakendaraan mp = new modeltabeldatakendaraan(dk);
        frame.getTabelKendaraan().setModel(mp);
    }
    
    public void insert(){
        datakendaraan dp = new datakendaraan();
        dp.setNama_kendaraan(frame.getJTxtNamaKendaraan().getText());
        dp.setPlat_kendaraan(frame.getJTxtPlat().getText());
        dp.setTipe_kendaraan((String) frame.getJDropTipe().getSelectedItem());
        Integer harga = Integer.parseInt(frame.getJTxtHarga().getText());
        dp.setHarga(harga);
        
        dp.setStatus((String) frame.getJDropStatus().getSelectedItem());
        
        impldatakendaraan.insert(dp);
    }
    
    public void update(int kodeKendaraan){
        datakendaraan dp = new datakendaraan();
        dp.setId_kendaraan(kodeKendaraan);
        dp.setNama_kendaraan(frame.getJTxtNamaKendaraan().getText());
        dp.setPlat_kendaraan(frame.getJTxtPlat().getText());
        dp.setTipe_kendaraan((String) frame.getJDropTipe().getSelectedItem());
        Integer harga = Integer.parseInt(frame.getJTxtHarga().getText());
        dp.setHarga(harga);
        
        dp.setStatus((String) frame.getJDropStatus().getSelectedItem());
        
        impldatakendaraan.update(dp);
    }
    public void delete(int kodeKendaraan) {
    datakendaraan dp = new datakendaraan();
    dp.setId_kendaraan(kodeKendaraan);

    impldatakendaraan.delete(kodeKendaraan);
    
}
}

