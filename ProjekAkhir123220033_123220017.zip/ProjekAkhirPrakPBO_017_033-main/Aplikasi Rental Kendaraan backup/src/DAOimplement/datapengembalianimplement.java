/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAOimplement;

import java.util.List;
import model.datakendaraan;
import model.datapeminjaman;
import model.datapengembalian;

/**
 *
 * @author ACER
 */
public interface datapengembalianimplement {
    public void delete(int id);
    public void updateStatusTersedia(int id);
    public List<datapengembalian> getAll();
}
